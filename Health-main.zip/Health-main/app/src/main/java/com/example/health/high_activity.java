package com.example.health;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class high_activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_high);
    }
    /*if (ans.contains("отсутствию")) {
            Toast.makeText(MainActivity.this,ans,Toast.LENGTH_LONG).show();
            Intent intent=new Intent(MainActivity.this,low_activity.class);
            startActivity(intent);
            }
        else {

            };
*/
}
