package com.example.health;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class low_activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_low);
    }
}